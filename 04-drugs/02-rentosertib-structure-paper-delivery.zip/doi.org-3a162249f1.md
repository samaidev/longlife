-

Scannell, J. W., Blanckley, A., Boldon, H. & Warrington, B. Diagnosing the decline in pharmaceutical R&D efficiency. Nat. Rev. Drug Discov. 11, 191–200 (2012).

[Article](https://doi.org/10.1038%2Fnrd3681) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC38XivFyhtrY%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=22378269) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Diagnosing%20the%20decline%20in%20pharmaceutical%20R%26D%20efficiency&journal=Nat.%20Rev.%20Drug%20Discov.&doi=10.1038%2Fnrd3681&volume=11&pages=191-200&publication_year=2012&author=Scannell%2CJW&author=Blanckley%2CA&author=Boldon%2CH&author=Warrington%2CB)

-

Berdigaliyev, N. & Aljofan, M. An overview of drug discovery and development. Future Med Chem. 12, 939–947 (2020).

[Article](https://doi.org/10.4155%2Ffmc-2019-0307) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB3cXpslygt74%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=32270704) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=An%20overview%20of%20drug%20discovery%20and%20development&journal=Future%20Med%20Chem.&doi=10.4155%2Ffmc-2019-0307&volume=12&pages=939-947&publication_year=2020&author=Berdigaliyev%2CN&author=Aljofan%2CM)

-

Pun, F. W., Ozerov, I. V. & Zhavoronkov, A. AI-powered therapeutic target discovery. Trends Pharmacol. Sci. 44, 561–572 (2023).

[Article](https://doi.org/10.1016%2Fj.tips.2023.06.010) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB3sXhsVCrs7zE) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=37479540) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=AI-powered%20therapeutic%20target%20discovery&journal=Trends%20Pharmacol.%20Sci.&doi=10.1016%2Fj.tips.2023.06.010&volume=44&pages=561-572&publication_year=2023&author=Pun%2CFW&author=Ozerov%2CIV&author=Zhavoronkov%2CA)

-

Qureshi, R. et al. AI in drug discovery and its clinical relevance. Heliyon 9, e17575 (2023).

[Article](https://doi.org/10.1016%2Fj.heliyon.2023.e17575) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB3sXhsVaqtbvE) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=37396052) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC10302550) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=AI%20in%20drug%20discovery%20and%20its%20clinical%20relevance&journal=Heliyon&doi=10.1016%2Fj.heliyon.2023.e17575&volume=9&publication_year=2023&author=Qureshi%2CR)

-

You, Y. et al. Artificial intelligence in cancer target identification and drug discovery. Signal Transduct. Target. Ther. 7, 156 (2022).

[Article](https://doi.org/10.1038%2Fs41392-022-00994-0) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35538061) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC9090746) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Artificial%20intelligence%20in%20cancer%20target%20identification%20and%20drug%20discovery&journal=Signal%20Transduct.%20Target.%20Ther.&doi=10.1038%2Fs41392-022-00994-0&volume=7&publication_year=2022&author=You%2CY)

-

Du, Y. et al. Machine learning-aided generative molecular design. Nat. Mach. Intell. 6, 589–604 (2024).

[Article](https://doi.org/10.1038%2Fs42256-024-00843-5) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Machine%20learning-aided%20generative%20molecular%20design&journal=Nat.%20Mach.%20Intell.&doi=10.1038%2Fs42256-024-00843-5&volume=6&pages=589-604&publication_year=2024&author=Du%2CY)

-

Cheng, Y., Gong, Y., Liu, Y., Song, B. & Zou, Q. Molecular design in drug discovery: a comprehensive review of deep generative models. Brief. Bioinform. 22, bbab344 (2021).

[Article](https://doi.org/10.1093%2Fbib%2Fbbab344) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34415297) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Molecular%20design%20in%20drug%20discovery%3A%20a%20comprehensive%20review%20of%20deep%20generative%20models&journal=Brief.%20Bioinform.&doi=10.1093%2Fbib%2Fbbab344&volume=22&publication_year=2021&author=Cheng%2CY&author=Gong%2CY&author=Liu%2CY&author=Song%2CB&author=Zou%2CQ)

-

Sousa, T., Correia, J., Pereira, V. & Rocha, M. Generative deep learning for targeted compound design. J. Chem. Inf. Model. 61, 5343–5361 (2021).

[Article](https://doi.org/10.1021%2Facs.jcim.0c01496) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB3MXitlWitb7F) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34699719) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Generative%20deep%20learning%20for%20targeted%20compound%20design&journal=J.%20Chem.%20Inf.%20Model.&doi=10.1021%2Facs.jcim.0c01496&volume=61&pages=5343-5361&publication_year=2021&author=Sousa%2CT&author=Correia%2CJ&author=Pereira%2CV&author=Rocha%2CM)

-

Ren, F. et al. A small-molecule TNIK inhibitor targets fibrosis in preclinical and clinical models. Nat. Biotechnol. [https://doi.org/10.1038/s41587-024-02143-0](https://doi.org/10.1038/s41587-024-02143-0) (2024).

-

Xu, J. et al. Discovery of a novel and potent cyclin-dependent kinase 8/19 (CDK8/19) inhibitor for the treatment of cancer. J. Med. Chem. 67, 8161–8171 (2024).

[Article](https://doi.org/10.1021%2Facs.jmedchem.4c00248) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB2cXptlOnuro%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=38690856) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Discovery%20of%20a%20novel%20and%20potent%20cyclin-dependent%20kinase%208%2F19%20%28CDK8%2F19%29%20inhibitor%20for%20the%20treatment%20of%20cancer&journal=J.%20Med.%20Chem.&doi=10.1021%2Facs.jmedchem.4c00248&volume=67&pages=8161-8171&publication_year=2024&author=Xu%2CJ)

-

Aliper, A. et al. Prediction of clinical trials outcomes based on target choice and clinical trial design with multi-modal artificial intelligence. Clin. Pharmacol. Ther. 114, 972–980 (2023).

[Article](https://doi.org/10.1002%2Fcpt.3008) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=37483175) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Prediction%20of%20clinical%20trials%20outcomes%20based%20on%20target%20choice%20and%20clinical%20trial%20design%20with%20multi-modal%20artificial%20intelligence&journal=Clin.%20Pharmacol.%20Ther.&doi=10.1002%2Fcpt.3008&volume=114&pages=972-980&publication_year=2023&author=Aliper%2CA)

-

Feuerriegel, S. et al. Causal machine learning for predicting treatment outcomes. Nat. Med. 30, 958–968 (2024).

[Article](https://doi.org/10.1038%2Fs41591-024-02902-1) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB2cXovF2jtLs%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=38641741) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Causal%20machine%20learning%20for%20predicting%20treatment%20outcomes&journal=Nat.%20Med.&doi=10.1038%2Fs41591-024-02902-1&volume=30&pages=958-968&publication_year=2024&author=Feuerriegel%2CS)

-

Feijoo, F., Palopoli, M., Bernstein, J., Siddiqui, S. & Albright, T. E. Key indicators of phase transition for clinical trials through machine learning. Drug Discov. Today 25, 414–421 (2020).

[Article](https://doi.org/10.1016%2Fj.drudis.2019.12.014) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=31926317) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Key%20indicators%20of%20phase%20transition%20for%20clinical%20trials%20through%20machine%20learning&journal=Drug%20Discov.%20Today&doi=10.1016%2Fj.drudis.2019.12.014&volume=25&pages=414-421&publication_year=2020&author=Feijoo%2CF&author=Palopoli%2CM&author=Bernstein%2CJ&author=Siddiqui%2CS&author=Albright%2CTE)

-

Artemov, A. V. et al. Integrated deep learned transcriptomic and structure-based predictor of clinical trials outcomes. Preprint at bioRxiv [https://doi.org/10.1101/095653](https://doi.org/10.1101/095653) (2016).

-

Gayvert, K. M., Madhukar, N. S. & Elemento, O. A data-driven approach to predicting successes and failures of clinical trials. Cell Chem. Biol. 23, 1294–1301 (2016).

[Article](https://doi.org/10.1016%2Fj.chembiol.2016.07.023) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC28XhsFajsLbE) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=27642066) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC5074862) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20data-driven%20approach%20to%20predicting%20successes%20and%20failures%20of%20clinical%20trials&journal=Cell%20Chem.%20Biol.&doi=10.1016%2Fj.chembiol.2016.07.023&volume=23&pages=1294-1301&publication_year=2016&author=Gayvert%2CKM&author=Madhukar%2CNS&author=Elemento%2CO)

-

Lavecchia, A. Navigating the frontier of drug-like chemical space with cutting-edge generative AI models. Drug Discov. Today 29, 104133 (2024).

[Article](https://doi.org/10.1016%2Fj.drudis.2024.104133) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB2cXhsl2qs7jM) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=39103144) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Navigating%20the%20frontier%20of%20drug-like%20chemical%20space%20with%20cutting-edge%20generative%20AI%20models&journal=Drug%20Discov.%20Today&doi=10.1016%2Fj.drudis.2024.104133&volume=29&publication_year=2024&author=Lavecchia%2CA)

-

Jiménez-Luna, J., Grisoni, F., Weskamp, N. & Schneider, G. Artificial intelligence in drug discovery: recent advances and future perspectives. Expert Opin. Drug Discov. 16, 949–959 (2021).

[Article](https://doi.org/10.1080%2F17460441.2021.1909567) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=33779453) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Artificial%20intelligence%20in%20drug%20discovery%3A%20recent%20advances%20and%20future%20perspectives&journal=Expert%20Opin.%20Drug%20Discov.&doi=10.1080%2F17460441.2021.1909567&volume=16&pages=949-959&publication_year=2021&author=Jim%C3%A9nez-Luna%2CJ&author=Grisoni%2CF&author=Weskamp%2CN&author=Schneider%2CG)

-

Mak, K.-K. & Pichika, M. R. Artificial intelligence in drug development: present status and future prospects. Drug Discov. Today 24, 773–780 (2019).

[Article](https://doi.org/10.1016%2Fj.drudis.2018.11.014) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=30472429) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Artificial%20intelligence%20in%20drug%20development%3A%20present%20status%20and%20future%20prospects&journal=Drug%20Discov.%20Today&doi=10.1016%2Fj.drudis.2018.11.014&volume=24&pages=773-780&publication_year=2019&author=Mak%2CK-K&author=Pichika%2CMR)

-

Jayatunga, M. K. P., Xie, W., Ruder, L., Schulze, U. & Meier, C. AI in small-molecule drug discovery: a coming wave? Nat. Rev. Drug Discov. 21, 175–176 (2022).

[Article](https://doi.org/10.1038%2Fd41573-022-00025-1) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB38XmtlChsbk%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35132242) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=AI%20in%20small-molecule%20drug%20discovery%3A%20a%20coming%20wave%3F&journal=Nat.%20Rev.%20Drug%20Discov.&doi=10.1038%2Fd41573-022-00025-1&volume=21&pages=175-176&publication_year=2022&author=Jayatunga%2CMKP&author=Xie%2CW&author=Ruder%2CL&author=Schulze%2CU&author=Meier%2CC)

-

Wong, C. H., Siah, K. W. & Lo, A. W. Estimation of clinical trial success rates and related parameters. Biostatistics 20, 273–286 (2019).

[Article](https://doi.org/10.1093%2Fbiostatistics%2Fkxx069) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=29394327) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Estimation%20of%20clinical%20trial%20success%20rates%20and%20related%20parameters&journal=Biostatistics&doi=10.1093%2Fbiostatistics%2Fkxx069&volume=20&pages=273-286&publication_year=2019&author=Wong%2CCH&author=Siah%2CKW&author=Lo%2CAW)

-

KP Jayatunga, M., Ayers, M., Bruens, L., Jayanth, D. & Meier, C. How successful are AI-discovered drugs in clinical trials? A first analysis and emerging lessons. Drug Discov. Today 29, 104009 (2024).

[Article](https://doi.org/10.1016%2Fj.drudis.2024.104009) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB2cXhtVOru7jI) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=38692505) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=How%20successful%20are%20AI-discovered%20drugs%20in%20clinical%20trials%3F%20A%20first%20analysis%20and%20emerging%20lessons&journal=Drug%20Discov.%20Today&doi=10.1016%2Fj.drudis.2024.104009&volume=29&publication_year=2024&author=KP%20Jayatunga%2CM&author=Ayers%2CM&author=Bruens%2CL&author=Jayanth%2CD&author=Meier%2CC)

-

Pun, F. W. et al. Identification of therapeutic targets for amyotrophic lateral sclerosis using PandaOmics—an AI-enabled biological target discovery platform. Front. Aging Neurosci. 14, 914017 (2022).

[Article](https://doi.org/10.3389%2Ffnagi.2022.914017) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB38Xitlyju7zF) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35837482) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC9273868) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Identification%20of%20therapeutic%20targets%20for%20amyotrophic%20lateral%20sclerosis%20using%20PandaOmics%E2%80%94an%20AI-enabled%20biological%20target%20discovery%20platform&journal=Front.%20Aging%20Neurosci.&doi=10.3389%2Ffnagi.2022.914017&volume=14&publication_year=2022&author=Pun%2CFW)

-

Pun, F. W. et al. Hallmarks of aging-based dual-purpose disease and age-associated targets predicted using PandaOmics AI-powered discovery engine. Aging 14, 2475–2506 (2022).

[Article](https://doi.org/10.18632%2Faging.203960) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB38XhvFKjsr7E) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35347083) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC9004567) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Hallmarks%20of%20aging-based%20dual-purpose%20disease%20and%20age-associated%20targets%20predicted%20using%20PandaOmics%20AI-powered%20discovery%20engine&journal=Aging&doi=10.18632%2Faging.203960&volume=14&pages=2475-2506&publication_year=2022&author=Pun%2CFW)

-

Raghu, G. et al. Diagnosis of idiopathic pulmonary fibrosis. An official ATS/ERS/JRS/ALAT clinical practice guideline. Am. J. Respir. Crit. Care Med. 198, e44–e68 (2018).

[Article](https://doi.org/10.1164%2Frccm.201807-1255ST) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=30168753) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Diagnosis%20of%20idiopathic%20pulmonary%20fibrosis.%20An%20official%20ATS%2FERS%2FJRS%2FALAT%20clinical%20practice%20guideline&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Frccm.201807-1255ST&volume=198&pages=e44-e68&publication_year=2018&author=Raghu%2CG)

-

Lederer, D. J. & Martinez, F. J. Idiopathic pulmonary fibrosis. N. Engl. J. Med. 378, 1811–1823 (2018).

[Article](https://doi.org/10.1056%2FNEJMra1705751) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC1cXpsFyqtr4%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=29742380) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Idiopathic%20pulmonary%20fibrosis&journal=N.%20Engl.%20J.%20Med.&doi=10.1056%2FNEJMra1705751&volume=378&pages=1811-1823&publication_year=2018&author=Lederer%2CDJ&author=Martinez%2CFJ)

-

Richeldi, L., Collard, H. R. & Jones, M. G. Idiopathic pulmonary fibrosis. Lancet 389, 1941–1952 (2017).

[Article](https://doi.org/10.1016%2FS0140-6736%2817%2930866-8) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=28365056) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Idiopathic%20pulmonary%20fibrosis&journal=Lancet&doi=10.1016%2FS0140-6736%2817%2930866-8&volume=389&pages=1941-1952&publication_year=2017&author=Richeldi%2CL&author=Collard%2CHR&author=Jones%2CMG)

-

Raghu, G. & Richeldi, L. Current approaches to the management of idiopathic pulmonary fibrosis. Respir. Med. 129, 24–30 (2017).

[Article](https://doi.org/10.1016%2Fj.rmed.2017.05.017) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=28732832) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Current%20approaches%20to%20the%20management%20of%20idiopathic%20pulmonary%20fibrosis&journal=Respir.%20Med.&doi=10.1016%2Fj.rmed.2017.05.017&volume=129&pages=24-30&publication_year=2017&author=Raghu%2CG&author=Richeldi%2CL)

-

Martinez, F. J. et al. Idiopathic pulmonary fibrosis. Nat. Rev. Dis. Prim. 3, 17074 (2017).

[Article](https://doi.org/10.1038%2Fnrdp.2017.74) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=29052582) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Idiopathic%20pulmonary%20fibrosis&journal=Nat.%20Rev.%20Dis.%20Prim.&doi=10.1038%2Fnrdp.2017.74&volume=3&publication_year=2017&author=Martinez%2CFJ)

-

Raghu, G. Idiopathic pulmonary fibrosis: lessons from clinical trials over the past 25 years. Eur. Respir. J. 50, 1701209 (2017).

[Article](https://doi.org/10.1183%2F13993003.01209-2017) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=29074545) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Idiopathic%20pulmonary%20fibrosis%3A%20lessons%20from%20clinical%20trials%20over%20the%20past%2025%20years&journal=Eur.%20Respir.%20J.&doi=10.1183%2F13993003.01209-2017&volume=50&publication_year=2017&author=Raghu%2CG)

-

King, T. E., Tooze, J. A., Schwarz, M. I., Brown, K. R. & Cherniack, R. M. Predicting survival in idiopathic pulmonary fibrosis. Am. J. Respir. Crit. Care Med. 164, 1171–1181 (2001).

[Article](https://doi.org/10.1164%2Fajrccm.164.7.2003140) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=11673205) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Predicting%20survival%20in%20idiopathic%20pulmonary%20fibrosis&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Fajrccm.164.7.2003140&volume=164&pages=1171-1181&publication_year=2001&author=King%2CTE&author=Tooze%2CJA&author=Schwarz%2CMI&author=Brown%2CKR&author=Cherniack%2CRM)

-

Wollin, L. et al. Mode of action of nintedanib in the treatment of idiopathic pulmonary fibrosis. Eur. Respir. J. 45, 1434–1445 (2015).

[Article](https://doi.org/10.1183%2F09031936.00174914) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC2MXhtVGju7jP) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=25745043) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC4416110) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Mode%20of%20action%20of%20nintedanib%20in%20the%20treatment%20of%20idiopathic%20pulmonary%20fibrosis&journal=Eur.%20Respir.%20J.&doi=10.1183%2F09031936.00174914&volume=45&pages=1434-1445&publication_year=2015&author=Wollin%2CL)

-

Aimo, A. et al. Pirfenidone for idiopathic pulmonary fibrosis and beyond. Card. Fail Rev. 8, e12 (2022).

[Article](https://doi.org/10.15420%2Fcfr.2021.30) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35516794) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC9062707) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Pirfenidone%20for%20idiopathic%20pulmonary%20fibrosis%20and%20beyond&journal=Card.%20Fail%20Rev.&doi=10.15420%2Fcfr.2021.30&volume=8&publication_year=2022&author=Aimo%2CA)

-

Noble, P. W. et al. Pirfenidone in patients with idiopathic pulmonary fibrosis (CAPACITY): two randomised trials. Lancet 377, 1760–1769 (2011).

[Article](https://doi.org/10.1016%2FS0140-6736%2811%2960405-4) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC3MXmtl2ktrg%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=21571362) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Pirfenidone%20in%20patients%20with%20idiopathic%20pulmonary%20fibrosis%20%28CAPACITY%29%3A%20two%20randomised%20trials&journal=Lancet&doi=10.1016%2FS0140-6736%2811%2960405-4&volume=377&pages=1760-1769&publication_year=2011&author=Noble%2CPW)

-

Richeldi, L. et al. Efficacy and safety of nintedanib in idiopathic pulmonary fibrosis. N. Engl. J. Med. 370, 2071–2082 (2014).

[Article](https://doi.org/10.1056%2FNEJMoa1402584) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=24836310) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Efficacy%20and%20safety%20of%20nintedanib%20in%20idiopathic%20pulmonary%20fibrosis&journal=N.%20Engl.%20J.%20Med.&doi=10.1056%2FNEJMoa1402584&volume=370&pages=2071-2082&publication_year=2014&author=Richeldi%2CL)

-

King, T. E. et al. A phase 3 trial of pirfenidone in patients with idiopathic pulmonary fibrosis. N. Engl. J. Med. 370, 2083–2092 (2014).

[Article](https://doi.org/10.1056%2FNEJMoa1402582) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=24836312) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=A%20phase%203%20trial%20of%20pirfenidone%20in%20patients%20with%20idiopathic%20pulmonary%20fibrosis&journal=N.%20Engl.%20J.%20Med.&doi=10.1056%2FNEJMoa1402582&volume=370&pages=2083-2092&publication_year=2014&author=King%2CTE)

-

Ewald, C. Y. et al. TNIK’s emerging role in cancer, metabolism, and age-related diseases. Trends Pharmacol. Sci. 45, 478–489 (2024).

[Article](https://doi.org/10.1016%2Fj.tips.2024.04.010) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB2cXhtFWqtrrL) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=38777670) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=TNIK%E2%80%99s%20emerging%20role%20in%20cancer%2C%20metabolism%2C%20and%20age-related%20diseases&journal=Trends%20Pharmacol.%20Sci.&doi=10.1016%2Fj.tips.2024.04.010&volume=45&pages=478-489&publication_year=2024&author=Ewald%2CCY)

-

Kamya, P. et al. PandaOmics: an AI-driven platform for therapeutic target and biomarker discovery. J. Chem. Inf. Model. 64, 3961–3969 (2024).

[Article](https://doi.org/10.1021%2Facs.jcim.3c01619) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB2cXktFKhsb0%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=38404138) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC11134400) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=PandaOmics%3A%20an%20AI-driven%20platform%20for%20therapeutic%20target%20and%20biomarker%20discovery&journal=J.%20Chem.%20Inf.%20Model.&doi=10.1021%2Facs.jcim.3c01619&volume=64&pages=3961-3969&publication_year=2024&author=Kamya%2CP)

-

Su, C.-Y. et al. Multi-ancestry proteome-phenome-wide Mendelian randomization offers a comprehensive protein-disease atlas and potential therapeutic targets. Preprint at medRxiv [https://doi.org/10.1101/2024.10.17.24315553](https://doi.org/10.1101/2024.10.17.24315553) (2024).

-

Oldham, J. M. et al. Proteomic biomarkers of survival in idiopathic pulmonary fibrosis. Am. J. Respir. Crit. Care Med. 209, 1111–1120 (2024).

[Article](https://doi.org/10.1164%2Frccm.202301-0117OC) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB2cXhtV2rs7bF) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=37847691) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Proteomic%20biomarkers%20of%20survival%20in%20idiopathic%20pulmonary%20fibrosis&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Frccm.202301-0117OC&volume=209&pages=1111-1120&publication_year=2024&author=Oldham%2CJM)

-

du Bois, R. M. et al. Forced vital capacity in patients with idiopathic pulmonary fibrosis: test properties and minimal clinically important difference. Am. J. Respir. Crit. Care Med. 184, 1382–1389 (2011).

[Article](https://doi.org/10.1164%2Frccm.201105-0840OC) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=21940789) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Forced%20vital%20capacity%20in%20patients%20with%20idiopathic%20pulmonary%20fibrosis%3A%20test%20properties%20and%20minimal%20clinically%20important%20difference&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Frccm.201105-0840OC&volume=184&pages=1382-1389&publication_year=2011&author=Bois%2CRM)

-

McCormack, M. C. Facing the noise: addressing the endemic variability in DLCO testing. Respir. Care 57, 17–25 (2012).

[Article](https://doi.org/10.4187%2Frespcare.01435) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=22222122) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Facing%20the%20noise%3A%20addressing%20the%20endemic%20variability%20in%20DLCO%20testing&journal=Respir.%20Care&doi=10.4187%2Frespcare.01435&volume=57&pages=17-25&publication_year=2012&author=McCormack%2CMC)

-

Collard, H. R. et al. Acute exacerbations of idiopathic pulmonary fibrosis. Am. J. Respir. Crit. Care Med. 176, 636–643 (2007).

[Article](https://doi.org/10.1164%2Frccm.200703-463PP) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=17585107) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Acute%20exacerbations%20of%20idiopathic%20pulmonary%20fibrosis&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Frccm.200703-463PP&volume=176&pages=636-643&publication_year=2007&author=Collard%2CHR)

-

Song, J. W., Hong, S.-B., Lim, C.-M., Koh, Y. & Kim, D. S. Acute exacerbation of idiopathic pulmonary fibrosis: incidence, risk factors and outcome. Eur. Respir. J. 37, 356–363 (2011).

[Article](https://doi.org/10.1183%2F09031936.00159709) [CAS](https://www.nature.com/articles/cas-redirect/1:STN:280:DC%2BC3M7lsFGltQ%3D%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=20595144) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Acute%20exacerbation%20of%20idiopathic%20pulmonary%20fibrosis%3A%20incidence%2C%20risk%20factors%20and%20outcome&journal=Eur.%20Respir.%20J.&doi=10.1183%2F09031936.00159709&volume=37&pages=356-363&publication_year=2011&author=Song%2CJW&author=Hong%2CS-B&author=Lim%2CC-M&author=Koh%2CY&author=Kim%2CDS)

-

Richeldi, L. et al. Trial of a preferential phosphodiesterase 4B inhibitor for idiopathic pulmonary fibrosis. N. Engl. J. Med. 386, 2178–2187 (2022).

[Article](https://doi.org/10.1056%2FNEJMoa2201737) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB38Xit1ersLrF) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35569036) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Trial%20of%20a%20preferential%20phosphodiesterase%204B%20inhibitor%20for%20idiopathic%20pulmonary%20fibrosis&journal=N.%20Engl.%20J.%20Med.&doi=10.1056%2FNEJMoa2201737&volume=386&pages=2178-2187&publication_year=2022&author=Richeldi%2CL)

-

Wootton, S. C. et al. Viral infection in acute exacerbation of idiopathic pulmonary fibrosis. Am. J. Respir. Crit. Care Med. 183, 1698–1702 (2011).

[Article](https://doi.org/10.1164%2Frccm.201010-1752OC) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=21471095) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC3136996) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Viral%20infection%20in%20acute%20exacerbation%20of%20idiopathic%20pulmonary%20fibrosis&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Frccm.201010-1752OC&volume=183&pages=1698-1702&publication_year=2011&author=Wootton%2CSC)

-

Collard, H. R. et al. Acute exacerbation of idiopathic pulmonary fibrosis. An International Working Group Report. Am. J. Respir. Crit. Care Med. 194, 265–275 (2016).

[Article](https://doi.org/10.1164%2Frccm.201604-0801CI) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC2sXhslakt73N) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=27299520) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Acute%20exacerbation%20of%20idiopathic%20pulmonary%20fibrosis.%20An%20International%20Working%20Group%20Report&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Frccm.201604-0801CI&volume=194&pages=265-275&publication_year=2016&author=Collard%2CHR)

-

Sokai, A. et al. Matrix metalloproteinase-10: a novel biomarker for idiopathic pulmonary fibrosis. Respir. Res. 16, 120 (2015).

[Article](https://link.springer.com/doi/10.1186/s12931-015-0280-9) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=26415518) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC4587921) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Matrix%20metalloproteinase-10%3A%20a%20novel%20biomarker%20for%20idiopathic%20pulmonary%20fibrosis&journal=Respir.%20Res.&doi=10.1186%2Fs12931-015-0280-9&volume=16&publication_year=2015&author=Sokai%2CA)

-

Enomoto, Y. et al. LTBP2 is secreted from lung myofibroblasts and is a potential biomarker for idiopathic pulmonary fibrosis. Clin. Sci. 132, 1565–1580 (2018).

[Article](https://doi.org/10.1042%2FCS20180435) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC1MXislOqurc%3D) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=LTBP2%20is%20secreted%20from%20lung%20myofibroblasts%20and%20is%20a%20potential%20biomarker%20for%20idiopathic%20pulmonary%20fibrosis&journal=Clin.%20Sci.&doi=10.1042%2FCS20180435&volume=132&pages=1565-1580&publication_year=2018&author=Enomoto%2CY)

-

Zou, M. et al. Plasma LTBP2 as a potential biomarker in differential diagnosis of connective tissue disease-associated interstitial lung disease and idiopathic pulmonary fibrosis: a pilot study. Clin. Exp. Med. 23, 4809–4816 (2023).

[Article](https://link.springer.com/doi/10.1007/s10238-023-01214-x) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB3sXitF2lurnL) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=37864077) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Plasma%20LTBP2%20as%20a%20potential%20biomarker%20in%20differential%20diagnosis%20of%20connective%20tissue%20disease-associated%20interstitial%20lung%20disease%20and%20idiopathic%20pulmonary%20fibrosis%3A%20a%20pilot%20study&journal=Clin.%20Exp.%20Med.&doi=10.1007%2Fs10238-023-01214-x&volume=23&pages=4809-4816&publication_year=2023&author=Zou%2CM)

-

Shang, D., Xu, X., Wang, D., Li, Y. & Liu, Y. Protein tyrosine phosphatase ζ enhances proliferation by increasing β-catenin nuclear expression in VHL-inactive human renal cell carcinoma cells. World J. Urol. 31, 1547–1554 (2013).

[Article](https://link.springer.com/doi/10.1007/s00345-013-1077-4) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC3sXhvVamtb7J) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=23588815) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Protein%20tyrosine%20phosphatase%20%CE%B6%20enhances%20proliferation%20by%20increasing%20%CE%B2-catenin%20nuclear%20expression%20in%20VHL-inactive%20human%20renal%20cell%20carcinoma%20cells&journal=World%20J.%20Urol.&doi=10.1007%2Fs00345-013-1077-4&volume=31&pages=1547-1554&publication_year=2013&author=Shang%2CD&author=Xu%2CX&author=Wang%2CD&author=Li%2CY&author=Liu%2CY)

-

Chilosi, M. et al. Aberrant Wnt/β-catenin pathway activation in idiopathic pulmonary fibrosis. Am. J. Pathol. 162, 1495–1502 (2003).

[Article](https://doi.org/10.1016%2FS0002-9440%2810%2964282-4) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BD3sXjsl2murs%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=12707032) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC1851206) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Aberrant%20Wnt%2F%CE%B2-catenin%20pathway%20activation%20in%20idiopathic%20pulmonary%20fibrosis&journal=Am.%20J.%20Pathol.&doi=10.1016%2FS0002-9440%2810%2964282-4&volume=162&pages=1495-1502&publication_year=2003&author=Chilosi%2CM)

-

Hu, X. et al. Dec1 deficiency ameliorates pulmonary fibrosis through the PI3K/AKT/GSK-3β/β-catenin integrated signaling pathway. Front. Pharmacol. 13, 829673 (2022).

[Article](https://doi.org/10.3389%2Ffphar.2022.829673) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB38XhtlWjtrvJ) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35355710) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC8959854) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Dec1%20deficiency%20ameliorates%20pulmonary%20fibrosis%20through%20the%20PI3K%2FAKT%2FGSK-3%CE%B2%2F%CE%B2-catenin%20integrated%20signaling%20pathway&journal=Front.%20Pharmacol.&doi=10.3389%2Ffphar.2022.829673&volume=13&publication_year=2022&author=Hu%2CX)

-

Devos, H., Zoidakis, J., Roubelakis, M. G., Latosinska, A. & Vlahou, A. Reviewing the regulators of COL1A1. Int. J. Mol. Sci. 24, 10004 (2023).

[Article](https://doi.org/10.3390%2Fijms241210004) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB3sXhsVSgsL7M) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=37373151) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC10298483) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Reviewing%20the%20regulators%20of%20COL1A1&journal=Int.%20J.%20Mol.%20Sci.&doi=10.3390%2Fijms241210004&volume=24&publication_year=2023&author=Devos%2CH&author=Zoidakis%2CJ&author=Roubelakis%2CMG&author=Latosinska%2CA&author=Vlahou%2CA)

-

Bibaki, E. et al. miR-185 and miR-29a are similarly expressed in the bronchoalveolar lavage cells in IPF and lung cancer but common targets DNMT1 and COL1A1 show disease specific patterns. Mol. Med. Rep. 17, 7105–7112 (2018).

[CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BC1cXhslWlsbjF) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=29568927) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC5928671) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=miR-185%20and%20miR-29a%20are%20similarly%20expressed%20in%20the%20bronchoalveolar%20lavage%20cells%20in%20IPF%20and%20lung%20cancer%20but%20common%20targets%20DNMT1%20and%20COL1A1%20show%20disease%20specific%20patterns&journal=Mol.%20Med.%20Rep.&volume=17&pages=7105-7112&publication_year=2018&author=Bibaki%2CE)

-

Wan, H. et al. Identification of Hub genes and pathways associated with idiopathic pulmonary fibrosis via bioinformatics analysis. Front. Mol. Biosci. 8, 711239 (2021).

[Article](https://doi.org/10.3389%2Ffmolb.2021.711239) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB3MXit1eisL%2FO) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34476240) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC8406749) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Identification%20of%20Hub%20genes%20and%20pathways%20associated%20with%20idiopathic%20pulmonary%20fibrosis%20via%20bioinformatics%20analysis&journal=Front.%20Mol.%20Biosci.&doi=10.3389%2Ffmolb.2021.711239&volume=8&publication_year=2021&author=Wan%2CH)

-

Huang, S. et al. Asporin promotes TGF-β–induced lung myofibroblast differentiation by facilitating Rab11-dependent recycling of TβRI. Am. J. Respir. Cell Mol. Biol. 66, 158–170 (2022).

[Article](https://doi.org/10.1165%2Frcmb.2021-0257OC) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB38XkvFKhsr4%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=34705621) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Asporin%20promotes%20TGF-%CE%B2%E2%80%93induced%20lung%20myofibroblast%20differentiation%20by%20facilitating%20Rab11-dependent%20recycling%20of%20T%CE%B2RI&journal=Am.%20J.%20Respir.%20Cell%20Mol.%20Biol.&doi=10.1165%2Frcmb.2021-0257OC&volume=66&pages=158-170&publication_year=2022&author=Huang%2CS)

-

Åhrman, E. et al. Quantitative proteomic characterization of the lung extracellular matrix in chronic obstructive pulmonary disease and idiopathic pulmonary fibrosis. J. Proteom. 189, 23–33 (2018).

[Article](https://doi.org/10.1016%2Fj.jprot.2018.02.027) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Quantitative%20proteomic%20characterization%20of%20the%20lung%20extracellular%20matrix%20in%20chronic%20obstructive%20pulmonary%20disease%20and%20idiopathic%20pulmonary%20fibrosis&journal=J.%20Proteom.&doi=10.1016%2Fj.jprot.2018.02.027&volume=189&pages=23-33&publication_year=2018&author=%C3%85hrman%2CE)

-

Todd, J. L. et al. Association of circulating proteins with death or lung transplant in patients with idiopathic pulmonary fibrosis in the IPF-PRO Registry Cohort. Lung 200, 11–18 (2022).

[Article](https://link.springer.com/doi/10.1007/s00408-021-00505-y) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB38XhtVKgu73P) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35066606) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC8881240) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Association%20of%20circulating%20proteins%20with%20death%20or%20lung%20transplant%20in%20patients%20with%20idiopathic%20pulmonary%20fibrosis%20in%20the%20IPF-PRO%20Registry%20Cohort&journal=Lung&doi=10.1007%2Fs00408-021-00505-y&volume=200&pages=11-18&publication_year=2022&author=Todd%2CJL)

-

Acharya, P. S., Zukas, A., Chandan, V., Katzenstein, A.-L. A. & Puré, E. Fibroblast activation protein: a serine protease expressed at the remodeling interface in idiopathic pulmonary fibrosis. Hum. Pathol. 37, 352–360 (2006).

[Article](https://doi.org/10.1016%2Fj.humpath.2005.11.020) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BD28XhvVWgs7Y%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=16613331) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Fibroblast%20activation%20protein%3A%20a%20serine%20protease%20expressed%20at%20the%20remodeling%20interface%20in%20idiopathic%20pulmonary%20fibrosis&journal=Hum.%20Pathol.&doi=10.1016%2Fj.humpath.2005.11.020&volume=37&pages=352-360&publication_year=2006&author=Acharya%2CPS&author=Zukas%2CA&author=Chandan%2CV&author=Katzenstein%2CA-LA&author=Pur%C3%A9%2CE)

-

Hoffman, E. T. et al. Regional and disease specific human lung extracellular matrix composition. Biomaterials 293, 121960 (2023).

[Article](https://doi.org/10.1016%2Fj.biomaterials.2022.121960) [CAS](https://www.nature.com/articles/cas-redirect/1:CAS:528:DC%2BB38XjtF2qs7bJ) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=36580718) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Regional%20and%20disease%20specific%20human%20lung%20extracellular%20matrix%20composition&journal=Biomaterials&doi=10.1016%2Fj.biomaterials.2022.121960&volume=293&publication_year=2023&author=Hoffman%2CET)

-

Shum, L. Chondroadherin binds to type II collagen. Arthritis Res. Ther. 3, 72650 (2001).

[Article](https://link.springer.com/doi/10.1186/ar-2001-72650) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Chondroadherin%20binds%20to%20type%20II%20collagen&journal=Arthritis%20Res.%20Ther.&doi=10.1186%2Far-2001-72650&volume=3&publication_year=2001&author=Shum%2CL)

-

Raghu, G. et al. Idiopathic pulmonary fibrosis (an update) and progressive pulmonary fibrosis in adults: an official ATS/ERS/JRS/ALAT clinical practice guideline. Am. J. Respir. Crit. Care Med. 205, e18–e47 (2022).

[Article](https://doi.org/10.1164%2Frccm.202202-0399ST) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35486072) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC9851481) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Idiopathic%20pulmonary%20fibrosis%20%28an%20update%29%20and%20progressive%20pulmonary%20fibrosis%20in%20adults%3A%20an%20official%20ATS%2FERS%2FJRS%2FALAT%20clinical%20practice%20guideline&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Frccm.202202-0399ST&volume=205&pages=e18-e47&publication_year=2022&author=Raghu%2CG)

-

Graham, B. L. et al. Standardization of Spirometry 2019 Update. An Official American Thoracic Society and European Respiratory Society Technical Statement. Am. J. Respir. Crit. Care Med. 200, e70–e88 (2019).

[Article](https://doi.org/10.1164%2Frccm.201908-1590ST) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=31613151) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC6794117) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Standardization%20of%20Spirometry%202019%20Update.%20An%20Official%20American%20Thoracic%20Society%20and%20European%20Respiratory%20Society%20Technical%20Statement&journal=Am.%20J.%20Respir.%20Crit.%20Care%20Med.&doi=10.1164%2Frccm.201908-1590ST&volume=200&pages=e70-e88&publication_year=2019&author=Graham%2CBL)

-

Graham, B. L. et al. 2017 ERS/ATS standards for single-breath carbon monoxide uptake in the lung. Eur. Respir. J. 49, 1600016 (2017).

[Article](https://doi.org/10.1183%2F13993003.00016-2016) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=28049168) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=2017%20ERS%2FATS%20standards%20for%20single-breath%20carbon%20monoxide%20uptake%20in%20the%20lung&journal=Eur.%20Respir.%20J.&doi=10.1183%2F13993003.00016-2016&volume=49&publication_year=2017&author=Graham%2CBL)

-

Birring, S. S. et al. Development of a symptom specific health status measure for patients with chronic cough: Leicester Cough Questionnaire (LCQ). Thorax [https://doi.org/10.1136/thorax.58.4.339](https://doi.org/10.1136/thorax.58.4.339) (2003).

-

Rebelo, P. et al. Minimal clinically important differences for patient-reported outcome measures of cough and sputum in patients with COPD. Int J. Chron. Obstruct. Pulmon. Dis. 15, 201–212 (2020).

[Article](https://doi.org/10.2147%2FCOPD.S219480) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=32099345) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC6996113) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Minimal%20clinically%20important%20differences%20for%20patient-reported%20outcome%20measures%20of%20cough%20and%20sputum%20in%20patients%20with%20COPD&journal=Int%20J.%20Chron.%20Obstruct.%20Pulmon.%20Dis.&doi=10.2147%2FCOPD.S219480&volume=15&pages=201-212&publication_year=2020&author=Rebelo%2CP)

-

Berkhof, F. F. et al. The validity and precision of the Leicester Cough Questionnaire in COPD patients with chronic cough. Health Qual. Life Outcomes 10, 4 (2012).

[Article](https://link.springer.com/doi/10.1186/1477-7525-10-4) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=22230731) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC3311606) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20validity%20and%20precision%20of%20the%20Leicester%20Cough%20Questionnaire%20in%20COPD%20patients%20with%20chronic%20cough&journal=Health%20Qual.%20Life%20Outcomes&doi=10.1186%2F1477-7525-10-4&volume=10&publication_year=2012&author=Berkhof%2CFF)

-

Murray, M. P., Turnbull, K., MacQuarrie, S., Pentland, J. L. & Hill, A. T. Validation of the Leicester Cough Questionnaire in non-cystic fibrosis bronchiectasis. Eur. Respir. J. 34, 125–131 (2009).

[Article](https://doi.org/10.1183%2F09031936.00160508) [CAS](https://www.nature.com/articles/cas-redirect/1:STN:280:DC%2BD1MvltlGlsg%3D%3D) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=19196812) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Validation%20of%20the%20Leicester%20Cough%20Questionnaire%20in%20non-cystic%20fibrosis%20bronchiectasis&journal=Eur.%20Respir.%20J.&doi=10.1183%2F09031936.00160508&volume=34&pages=125-131&publication_year=2009&author=Murray%2CMP&author=Turnbull%2CK&author=MacQuarrie%2CS&author=Pentland%2CJL&author=Hill%2CAT)

-

Nguyen, A. M. et al. Leicester Cough Questionnaire validation and clinically important thresholds for change in refractory or unexplained chronic cough. Ther. Adv. Respir. Dis. 16, 17534666221099737 (2022).

[Article](https://doi.org/10.1177%2F17534666221099737) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=35614875) [PubMed Central](http://www.ncbi.nlm.nih.gov/pmchttps://www.nature.com/articles/PMC9149626) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=Leicester%20Cough%20Questionnaire%20validation%20and%20clinically%20important%20thresholds%20for%20change%20in%20refractory%20or%20unexplained%20chronic%20cough&journal=Ther.%20Adv.%20Respir.%20Dis.&doi=10.1177%2F17534666221099737&volume=16&publication_year=2022&author=Nguyen%2CAM)

-

Milacic, M. et al. The Reactome Pathway Knowledgebase 2024. Nucleic Acids Res. 52, D672–D678 (2024).

[Article](https://doi.org/10.1093%2Fnar%2Fgkad1025) [PubMed](http://www.ncbi.nlm.nih.gov/entrez/query.fcgi?cmd=Retrieve&db=PubMed&dopt=Abstract&list_uids=37941124) [Google Scholar](http://scholar.google.com/scholar_lookup?&title=The%20Reactome%20Pathway%20Knowledgebase%202024&journal=Nucleic%20Acids%20Res.&doi=10.1093%2Fnar%2Fgkad1025&volume=52&publication_year=2024&author=Milacic%2CM)